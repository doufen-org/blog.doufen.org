'use strict';

import Draft from '../vendor/draft.js';

window.note = document.querySelector('.note');
window.draft = new Draft();
